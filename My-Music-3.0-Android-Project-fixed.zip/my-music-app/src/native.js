// Native media-session bridge disabled for stability on Android WebView.
// The web app uses the browser Media Session API when available.
