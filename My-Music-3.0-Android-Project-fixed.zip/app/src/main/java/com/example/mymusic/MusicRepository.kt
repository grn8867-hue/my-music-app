package com.example.mymusic

import android.content.ContentResolver
import android.provider.MediaStore

object MusicRepository {
    fun loadSongs(resolver: ContentResolver): List<MusicItem> {
        val result = mutableListOf<MusicItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        resolver.query(collection, projection, selection, null, sort)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val uri = "${MediaStore.Audio.Media.EXTERNAL_CONTENT_URI}/$id"
                result += MusicItem(
                    id = id,
                    title = c.getString(titleCol) ?: "알 수 없는 곡",
                    artist = c.getString(artistCol) ?: "알 수 없는 아티스트",
                    album = c.getString(albumCol) ?: "알 수 없는 앨범",
                    uri = uri,
                    durationMs = c.getLong(durationCol)
                )
            }
        }
        return result
    }
}
