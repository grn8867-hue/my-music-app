package com.example.mymusic

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyMusicTheme {
                MusicApp()
            }
        }
    }
}

@Composable
fun MusicApp(vm: MusicViewModel = viewModel()) {
    val songs by vm.songs.collectAsState()
    val query by vm.query.collectAsState()
    val selected by vm.selected.collectAsState()
    val playing by vm.playing.collectAsState()
    var showPermissionDialog by remember { mutableStateOf(false) }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.load()
        else showPermissionDialog = true
    }

    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            vm.app,
            permission
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) vm.load()
        else launcher.launch(permission)
        vm.connect()
    }

    val filtered = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter {
            it.title.contains(query, true) ||
            it.artist.contains(query, true) ||
            it.album.contains(query, true)
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F7F7),
        topBar = {
            if (query.isNotEmpty()) {
                TopAppBar(
                    title = {
                        Text(
                            text = query,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { vm.setQuery("") }) {
                            Icon(Icons.Default.ArrowBack, "뒤로")
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.setQuery("") }) {
                            Icon(Icons.Default.Search, "검색 닫기")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFFF7F7F7)
                    )
                )
            } else {
                TopAppBar(
                    title = {
                        Text(
                            "내 음악",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { vm.toggleDrawer() }) {
                            Icon(Icons.Default.Menu, "메뉴")
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.setSearchHint() }) {
                            Icon(Icons.Default.Search, "검색")
                        }
                        IconButton(onClick = { vm.showInfo() }) {
                            Icon(Icons.Default.MoreVert, "더보기")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFFF7F7F7)
                    )
                )
            }
        },
        bottomBar = {
            if (selected != null) {
                MiniPlayer(
                    song = selected!!,
                    playing = playing,
                    onPlay = { vm.togglePlay() },
                    onNext = { vm.next() },
                    onPrevious = { vm.previous() }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (vm.drawerOpen) {
                DrawerHeader(onClose = { vm.toggleDrawer() })
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filtered.size}곡",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { vm.sortByTitle() }) {
                    Icon(Icons.Default.Sort, "정렬")
                }
                IconButton(onClick = { vm.showQueue() }) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, "재생목록")
                }
            }

            Divider()

            if (filtered.isEmpty()) {
                EmptyMusicView(
                    permissionMissing = songs.isEmpty(),
                    onRetry = { vm.load() }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(filtered, key = { it.id }) { song ->
                        SongRow(
                            song = song,
                            isSelected = selected?.id == song.id,
                            favorite = vm.isFavorite(song.id),
                            onClick = { vm.play(song) },
                            onFavorite = { vm.toggleFavorite(song.id) }
                        )
                    }
                }
            }
        }
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("음악 권한이 필요해요") },
            text = { Text("기기에 저장된 음악을 표시하려면 설정에서 음악 및 오디오 권한을 허용해 주세요.") },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionDialog = false
                    launcher.launch(permission)
                }) { Text("다시 허용") }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) { Text("닫기") }
            }
        )
    }

    if (vm.infoDialog) {
        AlertDialog(
            onDismissRequest = { vm.hideInfo() },
            title = { Text("My Music") },
            text = { Text("내 음악을 빠르게 찾고 재생하는 음악 플레이어입니다.") },
            confirmButton = {
                TextButton(onClick = { vm.hideInfo() }) { Text("확인") }
            }
        )
    }
}

@Composable
private fun DrawerHeader(onClose: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8EAF6)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MusicNote, null)
                }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("My Music", fontWeight = FontWeight.Bold)
                    Text("음악 라이브러리", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.ArrowBack, "닫기")
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("노래", fontWeight = FontWeight.SemiBold)
            Text("앨범", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
            Text("아티스트", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
            Text("즐겨찾기", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
        }
    }
}

@Composable
private fun SongRow(
    song: MusicItem,
    isSelected: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (isSelected) Color(0xFFEDEDED) else Color.Transparent)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFE5E5E5)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Album, null, tint = Color(0xFF777777))
        }

        Spacer(Modifier.size(14.dp))

        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
            Text(
                "${song.artist} • ${song.album}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall
            )
        }

        IconButton(onClick = onFavorite) {
            Icon(
                if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "즐겨찾기"
            )
        }

        IconButton(onClick = onClick) {
            Icon(
                if (isSelected) Icons.Default.Pause else Icons.Default.PlayArrow,
                "재생"
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: MusicItem,
    playing: Boolean,
    onPlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    Surface(
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        color = Color.White
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE5E5E5)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MusicNote, null)
                }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        song.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                IconButton(onClick = onPrevious) {
                    Icon(Icons.Default.SkipPrevious, "이전")
                }
                IconButton(onClick = onPlay) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "재생/일시정지"
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipNext, "다음")
                }
            }
        }
    }
}

@Composable
private fun EmptyMusicView(permissionMissing: Boolean, onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.MusicNote,
            contentDescription = null,
            modifier = Modifier.size(72.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            if (permissionMissing) "음악을 불러올 수 없어요" else "음악이 없어요",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (permissionMissing)
                "음악 및 오디오 권한을 허용한 뒤 다시 시도해 주세요."
            else
                "기기에 음악 파일이 있으면 여기에 표시됩니다."
        )
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onRetry) { Text("다시 불러오기") }
    }
}

class MusicViewModel(application: android.app.Application) :
    androidx.lifecycle.AndroidViewModel(application) {

    val app = application
    private val _songs = kotlinx.coroutines.flow.MutableStateFlow<List<MusicItem>>(emptyList())
    val songs = _songs
    private val _query = kotlinx.coroutines.flow.MutableStateFlow("")
    val query = _query
    private val _selected = kotlinx.coroutines.flow.MutableStateFlow<MusicItem?>(null)
    val selected = _selected
    private val _playing = kotlinx.coroutines.flow.MutableStateFlow(false)
    val playing = _playing

    private val favorites = mutableSetOf<Long>()
    private var controller: MediaController? = null
    var drawerOpen by mutableStateOf(false)
        private set
    var infoDialog by mutableStateOf(false)
        private set

    fun load() {
        _songs.value = runCatching {
            MusicRepository.loadSongs(app.contentResolver)
        }.getOrDefault(emptyList())
    }

    fun connect() {
        if (controller != null) return
        val token = SessionToken(app, ComponentName(app, MusicPlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { controller = future.get() }
        }, MoreExecutors.directExecutor())
    }

    fun play(song: MusicItem) {
        val c = controller ?: return
        _selected.value = song
        val item = PlayerMediaItem.Builder()
            .setUri(song.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .build()
            )
            .build()
        c.setMediaItem(item)
        c.prepare()
        c.play()
        _playing.value = true
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
            _playing.value = false
        } else {
            c.play()
            _playing.value = true
        }
    }

    fun next() {
        val list = _songs.value
        val current = _selected.value ?: return
        val index = list.indexOfFirst { it.id == current.id }
        if (index >= 0 && index + 1 < list.size) play(list[index + 1])
    }

    fun previous() {
        val list = _songs.value
        val current = _selected.value ?: return
        val index = list.indexOfFirst { it.id == current.id }
        if (index > 0) play(list[index - 1])
    }

    fun toggleFavorite(id: Long) {
        if (!favorites.add(id)) favorites.remove(id)
    }

    fun isFavorite(id: Long) = id in favorites

    fun setQuery(value: String) {
        _query.value = value
    }

    fun setSearchHint() {
        _query.value = ""
    }

    fun toggleDrawer() {
        drawerOpen = !drawerOpen
    }

    fun showInfo() {
        infoDialog = true
    }

    fun hideInfo() {
        infoDialog = false
    }

    fun showQueue() {
        // Queue UI is intentionally lightweight for this first stable build.
    }

    fun sortByTitle() {
        _songs.value = _songs.value.sortedBy { it.title.lowercase() }
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}

@Composable
fun MyMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = Color(0xFF1F1F1F),
            background = Color(0xFFF7F7F7),
            surface = Color.White
        ),
        content = content
    )
}
