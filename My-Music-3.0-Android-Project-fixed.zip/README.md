# My Music 3.0

Samsung Music 스타일의 Android 음악 플레이어를 처음부터 다시 만든 안정화 프로젝트입니다.

## 포함 기능
- 기기 음악 자동 검색
- Android 13+ 음악 및 오디오 권한 요청
- MP3/기기 오디오 재생
- 재생/일시정지
- 이전/다음 곡
- 검색
- 즐겨찾기
- 미니 플레이어
- Media3 기반 백그라운드 재생 서비스
- GitHub Actions에서 APK 자동 빌드

## 빌드
GitHub Actions의 `Build My Music APK`를 실행하고 Artifacts에서 `My-Music-APK`를 다운로드합니다.
