package com.bluemusic.player;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutionException;

public final class MainActivity extends AppCompatActivity {
    private final List<Song> allSongs = new ArrayList<>();
    private final Set<String> favorites = new HashSet<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) loadSongs(); else showEmpty("음악 접근 권한이 필요해요.");
            });

    private LinearLayout songContainer;
    private TextView nowTitle, nowArtist, emptyText;
    private ProgressBar progress;
    private TextView playButton, shuffleButton, repeatButton;
    private EditText search;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private boolean connected;
    private boolean shuffle;
    private int repeat = Player.REPEAT_MODE_OFF;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        connectController();
        if (hasAudioPermission()) loadSongs(); else permissionLauncher.launch(audioPermission());
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(12), dp(18), 0); root.setBackgroundColor(0xFFF7F8FA);
        TextView title = text("Blue Music", 30, 0xFF15171A); title.setTypeface(null, 1); root.addView(title, lp(-1, -2));
        TextView sub = text("내 음악", 14, 0xFF6F747B); root.addView(sub, lp(-1, -2));
        search = new EditText(this); search.setHint("음악 검색"); search.setSingleLine(true); search.setPadding(dp(16), 0, dp(16), 0); search.setBackgroundResource(com.bluemusic.player.R.drawable.bg_card); LinearLayout.LayoutParams sp = lp(-1, dp(52)); sp.topMargin=dp(14); root.addView(search, sp);

        ScrollView scroll = new ScrollView(this); songContainer = new LinearLayout(this); songContainer.setOrientation(LinearLayout.VERTICAL); songContainer.setPadding(0, dp(12), 0, dp(160)); scroll.addView(songContainer); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        emptyText = text("음악을 찾는 중…", 15, 0xFF6F747B); emptyText.setGravity(Gravity.CENTER); songContainer.addView(emptyText, lp(-1, dp(140)));

        LinearLayout mini = new LinearLayout(this); mini.setOrientation(LinearLayout.HORIZONTAL); mini.setGravity(Gravity.CENTER_VERTICAL); mini.setPadding(dp(14), dp(8), dp(8), dp(8)); mini.setBackgroundResource(R.drawable.bg_mini);
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); nowTitle=text("재생할 음악을 선택하세요",16,0xFF15171A); nowTitle.setTypeface(null,1); nowArtist=text("",12,0xFF6F747B); info.addView(nowTitle); info.addView(nowArtist); mini.addView(info, new LinearLayout.LayoutParams(0,-2,1));
        playButton=button("▶"); playButton.setOnClickListener(v -> { if(controller!=null){ if(controller.isPlaying()) controller.pause(); else controller.play(); }}); mini.addView(playButton, lp(dp(58),dp(52)));
        LinearLayout.LayoutParams mp=lp(-1,dp(70)); mp.bottomMargin=dp(8); root.addView(mini,mp);
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER);
        TextView prev=button("⏮"); prev.setOnClickListener(v->{if(controller!=null)controller.seekToPreviousMediaItem();}); controls.addView(prev,lp(dp(60),dp(50)));
        shuffleButton=button("셔플"); shuffleButton.setTextSize(12); shuffleButton.setOnClickListener(v->{shuffle=!shuffle; if(controller!=null)controller.setShuffleModeEnabled(shuffle); shuffleButton.setText(shuffle?"셔플 ✓":"셔플");}); controls.addView(shuffleButton,lp(dp(78),dp(50)));
        TextView next=button("⏭"); next.setOnClickListener(v->{if(controller!=null)controller.seekToNextMediaItem();}); controls.addView(next,lp(dp(60),dp(50)));
        repeatButton=button("반복"); repeatButton.setTextSize(12); repeatButton.setOnClickListener(v->{if(repeat==Player.REPEAT_MODE_OFF)repeat=Player.REPEAT_MODE_ALL; else if(repeat==Player.REPEAT_MODE_ALL)repeat=Player.REPEAT_MODE_ONE; else repeat=Player.REPEAT_MODE_OFF; if(controller!=null)controller.setRepeatMode(repeat); repeatButton.setText(repeat==Player.REPEAT_MODE_OFF?"반복":repeat==Player.REPEAT_MODE_ALL?"전체 반복":"한 곡 반복");}); controls.addView(repeatButton,lp(dp(90),dp(50)));
        root.addView(controls,lp(-1,dp(50)));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(1000); root.addView(progress,lp(-1,dp(3)));
        setContentView(root);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){renderSongs(s.toString());} public void afterTextChanged(Editable e){}});
    }

    private void connectController(){
        SessionToken token=new SessionToken(this,PlaybackService.class);
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{try{controller=controllerFuture.get(); connected=true; controller.addListener(new Player.Listener(){@Override public void onIsPlayingChanged(boolean isPlaying){updatePlayerUi();} @Override public void onMediaItemTransition(MediaItem item,int reason){updatePlayerUi();} @Override public void onPlaybackStateChanged(int state){updatePlayerUi();}}); updatePlayerUi();}catch(InterruptedException|ExecutionException e){showToast("재생 서비스 연결에 실패했습니다.");}},ContextCompat.getMainExecutor(this));
    }

    private void loadSongs(){
        allSongs.clear(); ContentResolver r=getContentResolver(); Uri collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM,MediaStore.Audio.Media.DURATION};
        String sel=MediaStore.Audio.Media.IS_MUSIC+" != 0 AND "+MediaStore.Audio.Media.DURATION+" > 0";
        try(Cursor c=r.query(collection,projection,sel,null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){
            if(c!=null){int id=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID), ti=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE), ar=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST), al=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM), du=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION); while(c.moveToNext()){long mediaId=c.getLong(id); String title=safe(c.getString(ti),"알 수 없는 곡"); String artist=safe(c.getString(ar),"알 수 없는 아티스트"); String album=safe(c.getString(al),""); long duration=c.getLong(du); Uri uri=Uri.withAppendedPath(collection,Long.toString(mediaId)); allSongs.add(new Song(Long.toString(mediaId),title,artist,album,duration,uri));}}
        }catch(Exception e){showEmpty("음악 목록을 읽지 못했어요."); return;}
        renderSongs("");
    }

    private void renderSongs(String query){
        songContainer.removeAllViews(); String q=query.trim().toLowerCase(Locale.getDefault()); int count=0;
        for(Song s:allSongs){if(!q.isEmpty() && !(s.title.toLowerCase(Locale.getDefault()).contains(q)||s.artist.toLowerCase(Locale.getDefault()).contains(q)||s.album.toLowerCase(Locale.getDefault()).contains(q))) continue; songContainer.addView(songRow(s)); count++;}
        if(count==0){emptyText=text(allSongs.isEmpty()?"기기에 음악이 없어요.":"검색 결과가 없어요.",15,0xFF6F747B); emptyText.setGravity(Gravity.CENTER); songContainer.addView(emptyText,lp(-1,dp(140)));}
    }

    private View songRow(Song s){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14),dp(10),dp(8),dp(10)); row.setBackgroundResource(R.drawable.bg_card); row.setOnClickListener(v->playSong(s));
        TextView icon=text("♪",24,0xFF0B57D0); row.addView(icon,lp(dp(48),dp(48)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); TextView t=text(s.title,16,0xFF15171A); t.setTypeface(null,1); TextView a=text(s.artist,13,0xFF6F747B); info.addView(t); info.addView(a); row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=button(favorites.contains(s.id)?"♥":"♡"); fav.setOnClickListener(v->{if(favorites.contains(s.id)) favorites.remove(s.id); else favorites.add(s.id); fav.setContentDescription(favorites.contains(s.id)?"즐겨찾기 해제":"즐겨찾기"); fav.setTag(favorites.contains(s.id)); fav.setText(favorites.contains(s.id)?"♥":"♡");}); row.addView(fav,lp(dp(50),dp(50)));
        LinearLayout.LayoutParams p=lp(-1,dp(72)); p.bottomMargin=dp(8); row.setLayoutParams(p); return row;
    }

    private void playSong(Song s){if(!connected||controller==null){showToast("잠시만 기다려 주세요.");return;} List<MediaItem> items=new ArrayList<>(); for(Song x:allSongs) items.add(mediaItem(x)); int index=0; for(int i=0;i<allSongs.size();i++)if(allSongs.get(i).id.equals(s.id)){index=i;break;} controller.setMediaItems(items,index,0); controller.setShuffleModeEnabled(shuffle); controller.setRepeatMode(repeat); controller.prepare(); controller.play(); updatePlayerUi();}
    private MediaItem mediaItem(Song s){MediaMetadata md=new MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).build(); return new MediaItem.Builder().setMediaId(s.id).setUri(s.uri).setMediaMetadata(md).build();}

    private void updatePlayerUi(){if(controller==null||controller.getCurrentMediaItem()==null){return;} MediaItem m=controller.getCurrentMediaItem(); nowTitle.setText(m.mediaMetadata.title==null?"재생 중":m.mediaMetadata.title); nowArtist.setText(m.mediaMetadata.artist==null?"":m.mediaMetadata.artist); playButton.setContentDescription(controller.isPlaying()?"일시정지":"재생"); playButton.setTag(controller.isPlaying()); playButton.setText(controller.isPlaying()?"Ⅱ":"▶"); long d=controller.getDuration(), p=controller.getCurrentPosition(); progress.setProgress(d>0?(int)Math.min(1000,(p*1000)/d):0); handler.postDelayed(this::updatePlayerUi,500);}

    private boolean hasAudioPermission(){return ContextCompat.checkSelfPermission(this,audioPermission())==PackageManager.PERMISSION_GRANTED;}
    private String audioPermission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;}
    private void showEmpty(String s){songContainer.removeAllViews(); TextView t=text(s,15,0xFF6F747B);t.setGravity(Gravity.CENTER);songContainer.addView(t,lp(-1,dp(180)));}
    private void showToast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s;}
    private TextView text(String s,float size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    private TextView button(String label){TextView b=text(label,20,0xFF15171A);b.setGravity(Gravity.CENTER);b.setBackgroundColor(0x00000000);b.setContentDescription(label);b.setTag(label);return b;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}

    @Override protected void onDestroy(){if(controller!=null)controller.release(); super.onDestroy();}
    private static final class Song{final String id,title,artist,album;final long duration;final Uri uri;Song(String i,String t,String a,String al,long d,Uri u){id=i;title=t;artist=a;album=al;duration=d;uri=u;}}
}
