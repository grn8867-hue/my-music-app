# Blue Music — fresh Android project

This project was created from scratch and does not reuse the previous My-Music projects.

## Build
Open the folder in Android Studio. Use JDK 17 and let Android Studio install missing SDK components. Then Build > Make Project and Run on an Android device.

## Playback architecture
Uses AndroidX Media3 1.11.1, ExoPlayer, and MediaSessionService for background playback and system media controls.

## Notes
A real device is required to verify device-specific audio codecs, OEM battery management, and media library behavior. The project includes defensive permission handling and avoids starting playback until a MediaController is connected.
