# My Music 4.1

기기에 저장된 음악을 재생하는 Android 음악 플레이어 프로젝트입니다.

## 4.1 개선 사항
- Android 13+ / Android 12 이하 음악 권한 처리
- 기기 음악 자동 검색 + 중복 ID 제거
- 곡명 / 아티스트 / 앨범 검색
- 노래 / 앨범 / 아티스트 / 즐겨찾기 라이브러리
- 즐겨찾기 영구 저장
- 앨범 / 아티스트를 누르면 전체 곡 상세 목록 표시
- 백그라운드 재생용 Media3 MediaSession 서비스
- 헤드폰/블루투스 해제 등 오디오 끊김 상황을 위한 noisy 처리
- 현재 재생 큐와 UI 동기화
- 다음 곡에 추가 동작
- 셔플 / 전체 반복 / 한 곡 반복
- 현재 재생 위치 슬라이더 및 실시간 시간 표시
- 재생 파일 오류 감지 및 재시도 안내
- 권한이 영구 거부된 경우 앱 설정으로 이동
- 정렬 방향 전환
- 미니 플레이어 + 전체 재생 화면
- Android 16(API 36) 대응 및 Edge-to-Edge 처리
- 최신 안정화 계열 AndroidX/Media3 의존성 적용
- GitHub Actions debug APK 빌드

## 빌드 방법
1. Android Studio에서 `music_project` 폴더를 엽니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. `app > Tasks > build > assembleDebug`를 실행합니다.
4. 생성된 `app-debug.apk`를 Android 기기에 설치합니다.

## 현재 빌드 기준
- compileSdk / targetSdk: 36
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- Kotlin: 2.2.10
- Compose BOM: 2026.09.00
- Media3: 1.11.1

이 프로젝트에는 Gradle Wrapper 바이너리를 포함하지 않았기 때문에 Android Studio가 설치한 호환 Gradle 또는 GitHub Actions의 Gradle 환경을 사용합니다.
