package com.example.mymusic

import android.content.ContentResolver
import android.provider.MediaStore
import androidx.core.content.ContentUris

object MusicRepository {
    fun loadSongs(resolver: ContentResolver): List<MusicItem> {
        val result = mutableListOf<MusicItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.IS_MUSIC
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        resolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol).orEmpty().ifBlank { "알 수 없는 곡" }
                val artist = cursor.getString(artistCol).orEmpty().ifBlank { "알 수 없는 아티스트" }
                val album = cursor.getString(albumCol).orEmpty().ifBlank { "알 수 없는 앨범" }
                result += MusicItem(
                    id = id,
                    title = title,
                    artist = artist,
                    album = album,
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                )
            }
        }
        return result.distinctBy { it.id }
    }
}
