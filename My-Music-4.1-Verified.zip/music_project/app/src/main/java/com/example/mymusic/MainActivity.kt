package com.example.mymusic

import android.Manifest
import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MyMusicTheme { MusicApp() } }
    }
}

enum class LibraryFilter { SONGS, ALBUMS, ARTISTS, FAVORITES }

enum class RepeatModeLabel { OFF, ALL, ONE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicApp(vm: MusicViewModel = viewModel()) {
    val songs by vm.songs.collectAsState()
    val query by vm.query.collectAsState()
    val selected by vm.selected.collectAsState()
    val playing by vm.playing.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val filter by vm.filter.collectAsState()
    val error by vm.error.collectAsState()
    val progress by vm.progress.collectAsState()
    val duration by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    var searchMode by remember { mutableStateOf(false) }
    var permissionDialog by remember { mutableStateOf(false) }
    var hasMusicPermission by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showNowPlaying by remember { mutableStateOf(false) }
    var selectedGroup by remember { mutableStateOf<Pair<String, List<MusicItem>>?>(null) }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMusicPermission = granted
        if (granted) vm.load() else permissionDialog = true
    }

    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(vm.app, permission) == PackageManager.PERMISSION_GRANTED
        hasMusicPermission = granted
        if (granted) vm.load() else launcher.launch(permission)
        vm.connect()
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            vm.refreshProgress()
            delay(500L)
        }
    }

    val filtered = remember(songs, query, filter, favorites) {
        val base = when (filter) {
            LibraryFilter.FAVORITES -> songs.filter { it.id in favorites }
            else -> songs
        }
        if (query.isBlank()) base else base.filter {
            it.title.contains(query, true) ||
                it.artist.contains(query, true) ||
                it.album.contains(query, true)
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F7F7),
        topBar = {
            if (searchMode) {
                TopAppBar(
                    title = {
                        TextField(
                            value = query,
                            onValueChange = vm::setQuery,
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            placeholder = { Text("곡, 아티스트, 앨범 검색") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            trailingIcon = {
                                if (query.isNotEmpty()) {
                                    IconButton(onClick = { vm.setQuery("") }) {
                                        Icon(Icons.Default.Close, "지우기")
                                    }
                                }
                            }
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { searchMode = false; vm.setQuery("") }) {
                            Icon(Icons.Default.ArrowBack, "뒤로")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF7F7F7))
                )
            } else {
                TopAppBar(
                    title = { Text("내 음악", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = vm::toggleDrawer) {
                            Icon(Icons.Default.Menu, "메뉴")
                        }
                    },
                    actions = {
                        IconButton(onClick = { searchMode = true }) {
                            Icon(Icons.Default.Search, "검색")
                        }
                        IconButton(onClick = vm::showInfo) {
                            Icon(Icons.Default.MoreVert, "더보기")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF7F7F7))
                )
            }
        },
        bottomBar = {
            selected?.let { song ->
                MiniPlayer(
                    song = song,
                    playing = playing,
                    onPlay = vm::togglePlay,
                    onPrevious = vm::previous,
                    onNext = vm::next,
                    onOpenQueue = { showQueue = true },
                    onOpenNowPlaying = { showNowPlaying = true }
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (vm.drawerOpen) {
                DrawerHeader(filter, vm::setFilter, vm::toggleDrawer)
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        filterLabel(filter),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(filterCountLabel(filter, filtered.size), style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = vm::toggleSort) { Icon(Icons.Default.Sort, "정렬") }
                IconButton(onClick = { showQueue = true }) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, "재생목록")
                }
                IconButton(onClick = vm::load) { Icon(Icons.Default.Refresh, "새로고침") }
            }
            HorizontalDivider()

            error?.let {
                ErrorBanner(it, onRetry = vm::load, onDismiss = vm::clearError)
            }

            if (filtered.isEmpty()) {
                EmptyMusicView(
                    permissionMissing = songs.isEmpty() && !hasMusicPermission,
                    noFavorites = filter == LibraryFilter.FAVORITES && songs.isNotEmpty(),
                    onRetry = vm::load
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    if (filter == LibraryFilter.SONGS || filter == LibraryFilter.FAVORITES) {
                        items(filtered, key = { it.id }) { song ->
                            SongRow(
                                song = song,
                                isSelected = selected?.id == song.id,
                                playing = selected?.id == song.id && playing,
                                favorite = song.id in favorites,
                                onClick = { vm.play(song) },
                                onFavorite = { vm.toggleFavorite(song.id) },
                                onPlayNext = { vm.playNext(song) }
                            )
                        }
                    } else {
                        val groups = if (filter == LibraryFilter.ALBUMS) {
                            filtered.groupBy { it.album }.toList()
                        } else {
                            filtered.groupBy { it.artist }.toList()
                        }
                        items(groups, key = { it.first }) { (name, groupSongs) ->
                            LibraryGroupRow(
                                name = name,
                                subtitle = "${groupSongs.size}곡",
                                onClick = { selectedGroup = name to groupSongs },
                                onPlay = { vm.play(groupSongs.first()) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (permissionDialog) {
        AlertDialog(
            onDismissRequest = { permissionDialog = false },
            title = { Text("음악 권한이 필요해요") },
            text = {
                Text("기기에 저장된 음악을 표시하려면 음악 및 오디오 권한을 허용해 주세요. 계속 거부한 경우 설정에서 권한을 켤 수 있어요.")
            },
            confirmButton = {
                TextButton(onClick = {
                    permissionDialog = false
                    launcher.launch(permission)
                }) { Text("다시 허용") }
            },
            dismissButton = {
                TextButton(onClick = {
                    permissionDialog = false
                    vm.app.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${vm.app.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("설정 열기") }
            }
        )
    }

    if (vm.infoDialog) {
        AlertDialog(
            onDismissRequest = vm::hideInfo,
            title = { Text("My Music 4.1") },
            text = {
                Text("기기 음악을 검색하고 즐겨찾기와 재생 큐를 관리하면서 백그라운드에서도 음악을 재생하는 플레이어입니다. 재생 오류, 셔플, 반복, 재생 위치도 실시간으로 동기화됩니다.")
            },
            confirmButton = { TextButton(onClick = vm::hideInfo) { Text("확인") } }
        )
    }

    if (showQueue) {
        QueueDialog(
            songs = songs,
            controllerQueue = vm.queue.collectAsState().value,
            selected = selected,
            onPlay = { vm.play(it); showQueue = false },
            onDismiss = { showQueue = false }
        )
    }

    selectedGroup?.let { (name, groupSongs) ->
        GroupDialog(
            title = name,
            songs = groupSongs,
            selected = selected,
            onPlay = { vm.play(it); selectedGroup = null },
            onDismiss = { selectedGroup = null }
        )
    }

    if (showNowPlaying && selected != null) {
        NowPlayingDialog(
            song = selected!!,
            playing = playing,
            progress = progress,
            duration = duration,
            shuffle = shuffle,
            repeat = repeat,
            onSeek = vm::seekTo,
            onPlay = vm::togglePlay,
            onPrevious = vm::previous,
            onNext = vm::next,
            onShuffle = vm::toggleShuffle,
            onRepeat = vm::cycleRepeat,
            onFavorite = { vm.toggleFavorite(selected!!.id) },
            favorite = selected!!.id in favorites,
            onDismiss = { showNowPlaying = false }
        )
    }
}

private fun filterLabel(filter: LibraryFilter) = when (filter) {
    LibraryFilter.SONGS -> "노래"
    LibraryFilter.ALBUMS -> "앨범"
    LibraryFilter.ARTISTS -> "아티스트"
    LibraryFilter.FAVORITES -> "즐겨찾기"
}

private fun filterCountLabel(filter: LibraryFilter, count: Int): String = when (filter) {
    LibraryFilter.SONGS, LibraryFilter.FAVORITES -> "$count곡"
    LibraryFilter.ALBUMS -> "$count개 앨범"
    LibraryFilter.ARTISTS -> "$count명"
}

@Composable
private fun DrawerHeader(filter: LibraryFilter, onFilter: (LibraryFilter) -> Unit, onClose: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8EAF6)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.MusicNote, null) }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("My Music", fontWeight = FontWeight.Bold)
                    Text("음악 라이브러리", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "닫기") }
            }
            Spacer(Modifier.height(12.dp))
            listOf(
                LibraryFilter.SONGS to "노래",
                LibraryFilter.ALBUMS to "앨범",
                LibraryFilter.ARTISTS to "아티스트",
                LibraryFilter.FAVORITES to "즐겨찾기"
            ).forEach { (item, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onFilter(item); onClose() }
                        .background(if (item == filter) Color(0xFFEDEDED) else Color.Transparent)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MusicNote, null, Modifier.size(20.dp))
                    Spacer(Modifier.size(12.dp))
                    Text(label, fontWeight = if (item == filter) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun SongRow(
    song: MusicItem,
    isSelected: Boolean,
    playing: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onPlayNext: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (isSelected) Color(0xFFEDEDED) else Color.Transparent)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFE5E5E5)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Album, null, tint = Color(0xFF777777)) }
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
            Text(
                "${song.artist} • ${song.album} • ${formatDuration(song.durationMs)}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall
            )
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "즐겨찾기")
        }
        IconButton(onClick = onPlayNext) { Icon(Icons.Default.MoreVert, "다음에 재생") }
        IconButton(onClick = onClick) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "재생") }
    }
}

@Composable
private fun LibraryGroupRow(name: String, subtitle: String, onClick: () -> Unit, onPlay: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFE5E5E5)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Album, null, tint = Color(0xFF777777)) }
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, "재생") }
    }
}

@Composable
private fun MiniPlayer(
    song: MusicItem,
    playing: Boolean,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenNowPlaying: () -> Unit
) {
    Surface(tonalElevation = 6.dp, shadowElevation = 8.dp, color = Color.White) {
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.weight(1f).clickable(onClick = onOpenNowPlaying), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFE5E5E5)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.MusicNote, null) }
                Spacer(Modifier.size(12.dp))
                Column {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "이전") }
            IconButton(onClick = onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "재생/일시정지") }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "다음") }
            IconButton(onClick = onOpenQueue) { Icon(Icons.AutoMirrored.Filled.QueueMusic, "재생목록") }
        }
    }
}

@Composable
private fun QueueDialog(
    songs: List<MusicItem>,
    controllerQueue: List<MusicItem>,
    selected: MusicItem?,
    onPlay: (MusicItem) -> Unit,
    onDismiss: () -> Unit
) {
    val displayQueue = controllerQueue.ifEmpty { songs }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("재생목록 (${displayQueue.size})") },
        text = {
            if (displayQueue.isEmpty()) {
                Text("재생할 음악이 없습니다.")
            } else {
                LazyColumn(Modifier.fillMaxWidth().height(420.dp)) {
                    items(displayQueue, key = { it.id }) { song ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onPlay(song) }
                                .padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (song.id == selected?.id) Icons.Default.PlayArrow else Icons.Default.MusicNote,
                                null,
                                Modifier.size(20.dp)
                            )
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    song.title,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (song.id == selected?.id) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(song.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("닫기") } }
    )
}

@Composable
private fun GroupDialog(
    title: String,
    songs: List<MusicItem>,
    selected: MusicItem?,
    onPlay: (MusicItem) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.fillMaxWidth().height(420.dp)) {
                items(songs, key = { it.id }) { song ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPlay(song) }
                            .padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (song.id == selected?.id) Icons.Default.PlayArrow else Icons.Default.MusicNote,
                            null,
                            Modifier.size(20.dp)
                        )
                        Spacer(Modifier.size(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(formatDuration(song.durationMs), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("닫기") } }
    )
}

@Composable
private fun NowPlayingDialog(
    song: MusicItem,
    playing: Boolean,
    progress: Long,
    duration: Long,
    shuffle: Boolean,
    repeat: RepeatModeLabel,
    onSeek: (Long) -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFavorite: () -> Unit,
    favorite: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("지금 재생 중") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(210.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color(0xFFE5E5E5)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Album, null, Modifier.size(92.dp)) }
                Spacer(Modifier.height(18.dp))
                Text(song.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                Slider(
                    value = progress.coerceAtLeast(0L).toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..duration.coerceAtLeast(1L).toFloat()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDuration(progress))
                    Text(formatDuration(duration))
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onShuffle) {
                        Icon(Icons.Default.Shuffle, "셔플", tint = if (shuffle) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "이전") }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                        IconButton(onClick = onPlay) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "재생", tint = Color.White)
                        }
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "다음") }
                    IconButton(onClick = onRepeat) {
                        Icon(Icons.Default.Repeat, "반복", tint = if (repeat != RepeatModeLabel.OFF) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                }
                TextButton(onClick = onFavorite) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                    Spacer(Modifier.size(6.dp))
                    Text(if (favorite) "즐겨찾기 해제" else "즐겨찾기 추가")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("닫기") } }
    )
}

@Composable
private fun ErrorBanner(message: String, onRetry: () -> Unit, onDismiss: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(message, Modifier.weight(1f), color = MaterialTheme.colorScheme.error, maxLines = 2, overflow = TextOverflow.Ellipsis)
        TextButton(onClick = onRetry) { Text("재시도") }
        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "닫기") }
    }
}

@Composable
private fun EmptyMusicView(permissionMissing: Boolean, noFavorites: Boolean, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.MusicNote, null, Modifier.size(72.dp))
        Spacer(Modifier.height(16.dp))
        Text(
            when {
                permissionMissing -> "음악을 불러올 수 없어요"
                noFavorites -> "즐겨찾기가 비어 있어요"
                else -> "음악이 없어요"
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                permissionMissing -> "음악 및 오디오 권한을 허용한 뒤 다시 시도해 주세요."
                noFavorites -> "노래 목록에서 하트 버튼을 눌러 즐겨찾기를 추가해 주세요."
                else -> "기기에 음악 파일이 있으면 여기에 표시됩니다."
            }
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text("다시 불러오기") }
    }
}

private fun formatDuration(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val totalSeconds = safe / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    val app = application
    private val _songs = MutableStateFlow<List<MusicItem>>(emptyList())
    val songs: StateFlow<List<MusicItem>> = _songs.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selected = MutableStateFlow<MusicItem?>(null)
    val selected: StateFlow<MusicItem?> = _selected.asStateFlow()

    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing.asStateFlow()

    private val prefs = application.getSharedPreferences("my_music", 0)
    private val _favorites = MutableStateFlow(loadFavorites())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    private val _filter = MutableStateFlow(LibraryFilter.SONGS)
    val filter: StateFlow<LibraryFilter> = _filter.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _progress = MutableStateFlow(0L)
    val progress: StateFlow<Long> = _progress.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _shuffle = MutableStateFlow(false)
    val shuffle: StateFlow<Boolean> = _shuffle.asStateFlow()

    private val _repeat = MutableStateFlow(RepeatModeLabel.OFF)
    val repeat: StateFlow<RepeatModeLabel> = _repeat.asStateFlow()

    private val _queue = MutableStateFlow<List<MusicItem>>(emptyList())
    val queue: StateFlow<List<MusicItem>> = _queue.asStateFlow()

    var drawerOpen by mutableStateOf(false)
        private set
    var infoDialog by mutableStateOf(false)
        private set

    private var controller: MediaController? = null
    private var pendingSong: MusicItem? = null
    private var connecting = false
    private var sortedAscending = true

    fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { MusicRepository.loadSongs(app.contentResolver) }
                .onSuccess { list ->
                    _songs.value = if (sortedAscending) list else list.asReversed()
                    _error.value = null
                    val current = _selected.value
                    if (current != null) _selected.value = _songs.value.firstOrNull { it.id == current.id }
                    syncQueueFromController()
                }
                .onFailure { _error.value = "음악을 불러오는 중 문제가 발생했어요. 권한과 저장공간을 확인해 주세요." }
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(app, ComponentName(app, MusicPlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            connecting = false
            runCatching {
                val c = future.get()
                controller = c
                _shuffle.value = c.shuffleModeEnabled
                _repeat.value = repeatLabel(c.repeatMode)
                c.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _playing.value = isPlaying
                    }

                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                        _shuffle.value = shuffleModeEnabled
                    }

                    override fun onRepeatModeChanged(repeatMode: Int) {
                        _repeat.value = repeatLabel(repeatMode)
                    }

                    override fun onMediaItemTransition(mediaItem: PlayerMediaItem?, reason: Int) {
                        val id = mediaItem?.mediaId?.toLongOrNull() ?: return
                        _selected.value = _songs.value.firstOrNull { it.id == id }
                        refreshProgress()
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        _playing.value = false
                        _error.value = "이 파일을 재생할 수 없어요. 파일이 손상되었거나 접근할 수 없을 수 있어요."
                    }
                })
                syncQueueFromController()
                pendingSong?.let { song ->
                    pendingSong = null
                    play(song)
                }
            }.onFailure {
                _error.value = "재생 서비스 연결에 실패했어요. 앱을 다시 열어 주세요."
            }
        }, MoreExecutors.directExecutor())
    }

    fun play(song: MusicItem) {
        val c = controller
        if (c == null) {
            pendingSong = song
            connect()
            return
        }
        if (_songs.value.isEmpty()) return

        val currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
        if (currentId == song.id) {
            _selected.value = song
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
            refreshProgress()
            return
        }

        val mediaItems = _songs.value.map(MusicItem::toMediaItem)
        val index = _songs.value.indexOfFirst { it.id == song.id }
        if (index < 0) {
            _error.value = "선택한 곡을 현재 음악 목록에서 찾을 수 없어요. 새로고침해 주세요."
            return
        }
        _selected.value = song
        c.setMediaItems(mediaItems, index, 0L)
        c.prepare()
        c.play()
        syncQueueFromController()
    }

    fun playNext(song: MusicItem) {
        val c = controller ?: return
        var currentIndex = c.currentMediaItemIndex
        if (currentIndex < 0 || _songs.value.none { it.id == song.id }) return
        if (c.currentMediaItem?.mediaId == song.id.toString()) return

        val existingIndex = (0 until c.mediaItemCount).firstOrNull {
            c.getMediaItemAt(it).mediaId == song.id.toString()
        }
        if (existingIndex != null) {
            c.removeMediaItem(existingIndex)
            if (existingIndex < currentIndex) currentIndex--
        }
        val insertAt = (currentIndex + 1).coerceAtMost(c.mediaItemCount)
        c.addMediaItem(insertAt, song.toMediaItem())
        syncQueueFromController()
    }

    fun togglePlay() {
        val c = controller ?: return
        when {
            c.isPlaying -> c.pause()
            c.currentMediaItem != null -> c.play()
            _songs.value.isNotEmpty() -> play(_songs.value.first())
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }

    fun seekTo(positionMs: Long) {
        val c = controller ?: return
        c.seekTo(positionMs.coerceAtLeast(0L))
        _progress.value = positionMs.coerceAtLeast(0L)
    }

    fun refreshProgress() {
        val c = controller ?: return
        _progress.value = c.currentPosition.coerceAtLeast(0L)
        _duration.value = c.duration.takeIf { it != Player.TIME_UNSET && it >= 0L } ?: selected.value?.durationMs.orZero()
        if (_selected.value == null) {
            val id = c.currentMediaItem?.mediaId?.toLongOrNull()
            _selected.value = _songs.value.firstOrNull { it.id == id }
        }
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        val next = when (_repeat.value) {
            RepeatModeLabel.OFF -> RepeatModeLabel.ALL
            RepeatModeLabel.ALL -> RepeatModeLabel.ONE
            RepeatModeLabel.ONE -> RepeatModeLabel.OFF
        }
        controller?.repeatMode = when (next) {
            RepeatModeLabel.OFF -> Player.REPEAT_MODE_OFF
            RepeatModeLabel.ALL -> Player.REPEAT_MODE_ALL
            RepeatModeLabel.ONE -> Player.REPEAT_MODE_ONE
        }
        _repeat.value = next
    }

    fun toggleFavorite(id: Long) {
        val next = _favorites.value.toMutableSet()
        if (!next.add(id)) next.remove(id)
        _favorites.value = next
        prefs.edit().putStringSet("favorites", next.map(Long::toString).toSet()).apply()
    }

    private fun loadFavorites(): Set<Long> = prefs
        .getStringSet("favorites", emptySet())
        .orEmpty()
        .mapNotNull(String::toLongOrNull)
        .toSet()

    fun setQuery(value: String) { _query.value = value }
    fun setFilter(value: LibraryFilter) { _filter.value = value }
    fun toggleDrawer() { drawerOpen = !drawerOpen }
    fun showInfo() { infoDialog = true }
    fun hideInfo() { infoDialog = false }
    fun clearError() { _error.value = null }

    fun toggleSort() {
        sortedAscending = !sortedAscending
        _songs.value = _songs.value.sortedBy { it.title.lowercase() }.let { if (sortedAscending) it else it.asReversed() }
    }

    private fun syncQueueFromController() {
        val c = controller ?: return
        _queue.value = buildList {
            for (index in 0 until c.mediaItemCount) {
                val media = c.getMediaItemAt(index)
                media.mediaId.toLongOrNull()?.let { id ->
                    _songs.value.firstOrNull { it.id == id }?.let(::add)
                }
            }
        }
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }

    private fun repeatLabel(mode: Int): RepeatModeLabel = when (mode) {
        Player.REPEAT_MODE_ALL -> RepeatModeLabel.ALL
        Player.REPEAT_MODE_ONE -> RepeatModeLabel.ONE
        else -> RepeatModeLabel.OFF
    }
}

private fun Long?.orZero(): Long = this ?: 0L

private fun MusicItem.toMediaItem(): PlayerMediaItem = PlayerMediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .build()
    )
    .build()

@Composable
fun MyMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = Color(0xFF1F1F1F),
            background = Color(0xFFF7F7F7),
            surface = Color.White
        ),
        content = content
    )
}
