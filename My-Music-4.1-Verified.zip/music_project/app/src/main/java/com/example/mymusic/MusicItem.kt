package com.example.mymusic

data class MusicItem(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: String,
    val durationMs: Long
)
