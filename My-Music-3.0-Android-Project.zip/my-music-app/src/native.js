import { Capacitor } from "@capacitor/core";
import { MediaSession } from "@jofr/capacitor-media-session";
// 네이티브 앱에서만 활성화: 포그라운드 서비스 + 알림/잠금화면 컨트롤
if (Capacitor.isNativePlatform()) window.NativeMedia = MediaSession;
