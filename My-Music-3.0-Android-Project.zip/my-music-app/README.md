# My Music 3.0 — 휴대폰용 음악 플레이어

기존 `my-music.html`을 유지하면서 휴대폰용 기능을 확장하고 Capacitor Android 앱으로 빌드할 수 있게 만든 프로젝트입니다.

## 업그레이드된 기능
- 곡 / 최근 재생 / 앨범 / 아티스트 / 플레이리스트 / 즐겨찾기
- 검색
- 미니 플레이어 + 전체 플레이어
- 셔플 / 반복 / 재생속도 / 수면 타이머
- 최근 재생 50곡
- 제목 / 아티스트 / 앨범 / 최근 재생 정렬
- 라이트 / 다크 / 기기 설정 테마
- 플레이리스트 생성 및 곡 추가
- IndexedDB 저장
- Android 미디어 세션 연동 코드

## 태블릿만으로 APK 만들기

이 프로젝트에는 `.github/workflows/build-apk.yml`이 포함되어 있습니다. GitHub Actions는 저장소에서 자동으로 빌드를 실행하고 결과 파일을 Artifact로 올릴 수 있습니다.

1. GitHub에서 새 저장소를 만듭니다.
2. 이 프로젝트의 파일 전체를 저장소에 업로드합니다.
3. GitHub의 **Actions** 탭에서 `Build Android APK`를 선택합니다.
4. **Run workflow**를 누릅니다.
5. 빌드가 성공하면 실행 결과의 **Artifacts**에서 `My-Music-debug-apk`를 다운로드합니다.
6. ZIP을 풀고 `app-debug.apk`를 휴대폰에 설치합니다.

## PC가 있는 경우

```bash
npm install
npx cap add android
npm run sync
npx cap open android
```

Capacitor는 기존 웹 앱에 Android 플랫폼을 추가하고 `npx cap sync`로 웹 파일을 네이티브 프로젝트에 동기화하는 방식입니다.

## 참고

현재 프로젝트는 기존 백그라운드 재생 플러그인과의 호환성을 위해 Capacitor 6 계열을 유지했습니다. 최신 Capacitor로 올릴 때는 사용 중인 미디어 세션 플러그인의 호환 버전을 먼저 확인하세요.
