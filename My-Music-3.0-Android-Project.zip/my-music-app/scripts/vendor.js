const fs=require("fs");fs.mkdirSync("www/vendor",{recursive:true});
try{fs.copyFileSync("node_modules/jsmediatags/dist/jsmediatags.min.js","www/vendor/jsmediatags.min.js");console.log("jsmediatags copied")}catch(e){console.log("vendor copy skipped:",e.message)}
