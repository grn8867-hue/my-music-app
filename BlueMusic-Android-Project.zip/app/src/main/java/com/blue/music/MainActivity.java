package com.blue.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 20;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private LinearLayout songList;
    private TextView nowTitle, nowArtist, elapsed, duration, empty;
    private SeekBar seekBar;
    private Button playButton, shuffleButton, repeatButton;
    private final List<Song> songs = new ArrayList<>();
    private boolean userSeeking = false;

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (hasAudioPermission()) connectController(); else requestAudioPermission();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(12));
        root.setBackgroundColor(0xFFF7F9FC);

        TextView brand = text("Blue Music", 28, 0xFF17202A);
        brand.setTypeface(null, 1);
        root.addView(brand, lp(-1, -2));
        TextView sub = text("내 기기의 음악을 깔끔하게 재생", 14, 0xFF68727D);
        root.addView(sub, lp(-1, -2));

        LinearLayout now = new LinearLayout(this);
        now.setOrientation(LinearLayout.VERTICAL);
        now.setPadding(dp(16), dp(14), dp(16), dp(12));
        now.setBackgroundResource(com.blue.music.R.drawable.bg_card);
        LinearLayout.LayoutParams nowLp = lp(-1, -2); nowLp.topMargin = dp(16); root.addView(now, nowLp);
        nowTitle = text("재생할 곡을 선택하세요", 18, 0xFF17202A); nowTitle.setTypeface(null,1); now.addView(nowTitle, lp(-1,-2));
        nowArtist = text("", 13, 0xFF68727D); now.addView(nowArtist, lp(-1,-2));
        LinearLayout seekRow = new LinearLayout(this); seekRow.setGravity(Gravity.CENTER_VERTICAL);
        elapsed = text("0:00", 11, 0xFF68727D); seekRow.addView(elapsed, lp(dp(38),-2));
        seekBar = new SeekBar(this); seekRow.addView(seekBar, new LinearLayout.LayoutParams(0,dp(36),1));
        duration = text("0:00",11,0xFF68727D); duration.setGravity(Gravity.RIGHT); seekRow.addView(duration, lp(dp(42),-2)); now.addView(seekRow, lp(-1,-2));

        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0,dp(4),0,0);
        shuffleButton = button("셔플"); repeatButton = button("반복");
        Button prev = button("⏮"); playButton = button("▶"); Button next = button("⏭");
        controls.addView(shuffleButton, btnLp()); controls.addView(prev, btnLp()); controls.addView(playButton, btnLp()); controls.addView(next, btnLp()); controls.addView(repeatButton, btnLp()); now.addView(controls, lp(-1,-2));

        TextView library = text("내 음악", 20, 0xFF17202A); library.setTypeface(null,1); LinearLayout.LayoutParams libLp=lp(-1,-2);libLp.topMargin=dp(18);root.addView(library,libLp);
        empty = text("음악을 불러오는 중…",14,0xFF68727D); root.addView(empty,lp(-1,-2));
        songList = new LinearLayout(this); songList.setOrientation(LinearLayout.VERTICAL);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this); scroll.addView(songList); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        playButton.setOnClickListener(v -> { if (controller != null) { if (controller.isPlaying()) controller.pause(); else controller.play(); } });
        prev.setOnClickListener(v -> { if(controller!=null) controller.seekToPreviousMediaItem(); });
        next.setOnClickListener(v -> { if(controller!=null) controller.seekToNextMediaItem(); });
        shuffleButton.setOnClickListener(v -> { if(controller!=null){ controller.setShuffleModeEnabled(!controller.getShuffleModeEnabled()); updateModeButtons(); }});
        repeatButton.setOnClickListener(v -> { if(controller!=null){ int m=controller.getRepeatMode(); controller.setRepeatMode(m==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL: m==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF); updateModeButtons(); }});
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onStartTrackingTouch(SeekBar b){userSeeking=true;} public void onStopTrackingTouch(SeekBar b){userSeeking=false;if(controller!=null)controller.seekTo(b.getProgress());} public void onProgressChanged(SeekBar b,int p,boolean f){if(f)elapsed.setText(formatMs(p));}});
    }

    private void connectController() {
        SessionToken token = new SessionToken(this, PlaybackService.class);
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean isPlaying){playButton.setText(isPlaying?"Ⅱ":"▶");}
                    @Override public void onMediaItemTransition(@Nullable MediaItem item,int reason){updateNowPlaying();}
                    @Override public void onPlaybackStateChanged(int state){updateNowPlaying();}
                });
                loadSongs();
                updateNowPlaying(); updateModeButtons();
            } catch(Exception e){ Toast.makeText(this,"재생 엔진을 시작하지 못했습니다.",Toast.LENGTH_LONG).show(); }
        }, MoreExecutors.directExecutor());
        handler.post(updateTask);
    }

    private void loadSongs(){
        songs.clear();
        String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM,MediaStore.Audio.Media.DURATION};
        String sel=MediaStore.Audio.Media.IS_MUSIC+"!=0 AND "+MediaStore.Audio.Media.DURATION+">0";
        try(Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,sel,null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){
            if(c!=null){int idI=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID),tI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE),aI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST),alI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM),dI=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
                while(c.moveToNext()){long id=c.getLong(idI);String title=c.getString(tI);String artist=c.getString(aI);String album=c.getString(alI);long dur=c.getLong(dI);songs.add(new Song(id,title==null?"제목 없음":title,artist==null||artist.isEmpty()?"알 수 없는 아티스트":artist,album==null?"":album,dur));}
            }
        }catch(Exception e){Toast.makeText(this,"음악 목록을 읽지 못했습니다.",Toast.LENGTH_LONG).show();}
        empty.setText(songs.isEmpty()?"기기에 음악 파일이 없습니다.":songs.size()+"곡");
        songList.removeAllViews();
        List<MediaItem> items=new ArrayList<>();
        for(Song s:songs){Uri uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,s.id);items.add(new MediaItem.Builder().setMediaId(String.valueOf(s.id)).setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).build()).build());
            TextView row=text(s.title+"\n"+s.artist,16,0xFF17202A);row.setPadding(dp(16),dp(14),dp(16),dp(14));row.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams rlp=lp(-1,-2);rlp.topMargin=dp(8);songList.addView(row,rlp);int index=songs.indexOf(s);row.setOnClickListener(v->{if(controller!=null){controller.seekToDefaultPosition(index);controller.play();}});
        }
        if(controller!=null){controller.setMediaItems(items,false);controller.prepare();}
    }

    private void updateNowPlaying(){
        if(controller==null||controller.getCurrentMediaItem()==null)return;MediaItem m=controller.getCurrentMediaItem();MediaMetadata md=m.mediaMetadata;nowTitle.setText(md.title==null?"재생 중":md.title);nowArtist.setText(md.artist==null?"":md.artist);long d=controller.getDuration();if(d>0){seekBar.setMax((int)Math.min(d,Integer.MAX_VALUE));duration.setText(formatMs(d));}
    }
    private void updateModeButtons(){if(controller==null)return;shuffleButton.setText(controller.getShuffleModeEnabled()?"셔플 ✓":"셔플");int r=controller.getRepeatMode();repeatButton.setText(r==Player.REPEAT_MODE_ONE?"반복 1":r==Player.REPEAT_MODE_ALL?"반복 ✓":"반복");}
    private final Runnable updateTask=new Runnable(){public void run(){if(controller!=null&&!userSeeking){long p=controller.getCurrentPosition();long d=controller.getDuration();if(d>0){seekBar.setMax((int)Math.min(d,Integer.MAX_VALUE));seekBar.setProgress((int)Math.min(p,Integer.MAX_VALUE));elapsed.setText(formatMs(p));duration.setText(formatMs(d));}}handler.postDelayed(this,500);}};

    private boolean hasAudioPermission(){return Build.VERSION.SDK_INT>=33?checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)==PackageManager.PERMISSION_GRANTED:checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
    private void requestAudioPermission(){String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;requestPermissions(new String[]{p},REQ_AUDIO);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)connectController();else empty.setText("음악 파일 접근 권한이 필요합니다.");}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(controller!=null)controller.release();super.onDestroy();}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setAllCaps(false);b.setBackgroundResource(R.drawable.bg_button);return b;}
    private LinearLayout.LayoutParams btnLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);p.setMargins(dp(3),0,dp(3),0);return p;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private String formatMs(long ms){if(ms<0)ms=0;long sec=ms/1000;return String.format(Locale.getDefault(),"%d:%02d",sec/60,sec%60);}
    private static class Song{long id;String title,artist,album;long duration;Song(long i,String t,String a,String al,long d){id=i;title=t;artist=a;album=al;duration=d;}}
}
