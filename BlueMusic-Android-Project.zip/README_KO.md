# Blue Music — 새 Android 음악 플레이어

기존 프로젝트를 사용하지 않고 새로 만든 Android 음악 플레이어 프로젝트입니다.

## 포함 기능
- 기기 내 음악 자동 검색
- 제목/아티스트 목록
- 재생/일시정지/이전/다음
- 셔플/전체 반복/한 곡 반복
- 재생 위치 SeekBar
- 화면을 꺼도 계속되는 백그라운드 재생
- Android 시스템 미디어 컨트롤/잠금화면 연동을 위한 MediaSession
- 단순한 Samsung One UI 느낌의 밝은 UI

## 빌드
Android Studio에서 이 폴더를 열고 Gradle Sync 후 `app`을 실행하세요.

요구 환경: JDK 17, Android SDK 36, Gradle 8.13, Android Gradle Plugin 8.13.2.
Media3 1.11.1을 사용합니다.
